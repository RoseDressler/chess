import os
import pickle

savefile_name = "savegame.p"
class SaveLoad:

    def __init__(self) -> None:
        super().__init__()

    def save_exists(self):
        return os.path.exists(savefile_name)

    def save(self, chessgame):
        pickle.dump(chessgame, open(savefile_name, "wb"))

    def load(self):
        return pickle.load(open(savefile_name, "rb"))

    def saves(self, chessgame):
        return pickle.dumps(chessgame)

    def loads(self, bytes):
        return pickle.loads(bytes)


