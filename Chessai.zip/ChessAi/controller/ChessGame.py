from typing import Tuple

from model.Color import Color
from model.GameStatus import GameStatus
from model import GameboardType
from controller.BoardEvaluation import is_check, clone_board, board_move_piece, simulate_move, is_check_mate
from model.pieces.Bishop import Bishop
from model.pieces.King import King
from model.pieces.Knight import Knight
from model.Move import Move
from model.MoveStatus import MoveStatus
from model.pieces.Piece import Piece
from model.pieces.Queen import Queen
from model.pieces.Rook import Rook
from model.pieces.Pawn import Pawn

from view.ChessView import ChessView


# Missing special cases:
#  Rochade
#  en passant
#  pawn promotion



class ChessGame:
    # ive decided since the number of pieces is capped but the type of pieces is not (pawn transformations), I've already coded much of the modularity to support just using a dictionary of pieces
    def __init__(self, chess_view: ChessView, players_color: Color = Color.WHITE):
        self.view = chess_view
        self.playersturn: Color = players_color
        self.gameboard: GameboardType = {}
        self._place_pieces()

    def _place_pieces(self):

        for i in range(0, 8):
            self.gameboard[(i, 1)] = Pawn(Color.WHITE)
            self.gameboard[(i, 6)] = Pawn(Color.BLACK)

        placers = [Rook, Knight, Bishop, King, Queen, Bishop, Knight, Rook]
        for i in range(0, 8):
            self.gameboard[(i, 0)] = placers[i](Color.WHITE)
            self.gameboard[(i, 7)] = placers[i](Color.BLACK)

    def main(self) -> GameStatus:
        self.view.on_game_start(self.gameboard)
        game_status = GameStatus.QUIT
        while True:
            message = ""
            move = self.view.on_turn_start(self.gameboard, self.playersturn)
            status = self._move_piece(move)
            self.view.on_turn_end(self.gameboard, status)
            if status == MoveStatus.STOP_AND_SAVE:
                game_status = GameStatus.SAVE
                break
            if status == MoveStatus.CHECK_MATE:
                winner = self.playersturn.get_other_color()
                if winner == Color.WHITE:
                    game_status = GameStatus.WON_WHITE
                else:
                    game_status = GameStatus.WON_BLACK
                break
            elif status == MoveStatus.DRAW:
                game_status = GameStatus.DRAW
                break
        self.view.on_game_end(self.gameboard)
        return game_status

    def _move_piece(self, move: Move) -> MoveStatus:
        startpos: Tuple[int, int]
        endpos: Tuple[int, int]

        # Provisorisches Speichern
        if move.fromY == 8:
            return MoveStatus.STOP_AND_SAVE

        startpos, endpos = (move.fromX, move.fromY), (move.toX, move.toY)
        move_status = MoveStatus.VALID_MOVE

        try:
            target: Piece = self.gameboard[startpos]
        except:
            message = "could not find piece; index probably out of range"
            return MoveStatus.NO_PIECE

        # print("found " + str(target))
        if target.color != self.playersturn:
            message = "you aren't allowed to move that piece this turn"
            return MoveStatus.INVALID_COLOR
        if target.is_valid(endpos, self.gameboard):
            # Move the piece on a clone, only if the move is valid confirm it
            check_status, check_color = simulate_move(self.gameboard, move)
            if check_status and self.playersturn == check_color:
                return MoveStatus.MOVE_WOULD_PUT_PLAYER_IN_CHECK
            # player has to resolve check

            # Valid move. Next players turn
            board_move_piece(self.gameboard, move)

            check_status, check_color = is_check(self.gameboard)
            if check_status and self.playersturn != check_color:
                if is_check_mate(self.gameboard, self.playersturn):
                    move_status = MoveStatus.CHECK_MATE
                else:
                    move_status = MoveStatus.CHECK
            elif not check_status:
                if is_check_mate(self.gameboard, self.playersturn):
                    move_status = MoveStatus.DRAW

            if self.playersturn == Color.BLACK:
                self.playersturn = Color.WHITE
            else:
                self.playersturn = Color.BLACK
            return move_status
        else:
            return MoveStatus.MOVE_NOT_AVAILABLE
