from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.MoveStatus import MoveStatus
from view.ChessView import ChessView


class MockChessView(ChessView):

    def __init__(self, white_moves: [Move], black_moves: [Move]) -> None:
        super().__init__()
        self.white_moves = white_moves
        self.black_moves = black_moves

    def get_move(self, turn_color: Color):
        if turn_color == Color.WHITE:
            next_move = self.white_moves.pop(0)
        else:
            next_move = self.black_moves.pop(0)
        return next_move

    def on_game_start(self, gameboard: GameboardType):
        super().on_game_start(gameboard)

    def on_turn_start(self, gameboard: GameboardType, turn_color: Color) -> Move:
        super().on_turn_start(gameboard, turn_color)
        return self.get_move(turn_color)

    def on_turn_end(self, gameboard: GameboardType, move_status: MoveStatus):
        super().on_turn_end(gameboard, move_status)

    def on_game_end(self, gameboard: GameboardType):
        super().on_game_end(gameboard)

