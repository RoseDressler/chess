import unittest

from ai.AI import AI
from controller.ChessGame import ChessGame
from controller.SaveLoad import SaveLoad
from model.Color import Color
from model.pieces.Pawn import Pawn
from view.ConsoleChessField import ConsoleChessField


class SaveTest(unittest.TestCase):
    def test_save_load_works_with_bot(self):
        save_load = SaveLoad()
        consoleField = ConsoleChessField(True, Color.WHITE, AI(Color.BLACK))
        chess = ChessGame(consoleField)
        chess.gameboard = {(1, 1): Pawn(Color.WHITE)}

        bytes = save_load.saves(chess)
        res = save_load.loads(bytes)

        self.assertEqual(Color.WHITE, res.gameboard[(1, 1)].color)



if __name__ == '__main__':
    unittest.main()
