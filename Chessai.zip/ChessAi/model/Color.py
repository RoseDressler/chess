from enum import Enum


class Color(Enum):
    BLACK = 1
    WHITE = 2

    def __repr__(self):
        return super().__repr__()

    def __str__(self):
        return self.name.lower()

    def get_other_color(self):
        if self == Color.BLACK:
            return Color.WHITE
        return Color.BLACK
