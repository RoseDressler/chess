from enum import Enum


class PieceType(Enum):
    PAWN = 1
    ROOK = 2
    KNIGHT = 3
    BISHOP = 4
    KING = 5
    QUEEN = 6
