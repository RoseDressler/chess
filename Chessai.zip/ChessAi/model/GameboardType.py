from typing import Tuple

from model.pieces.Piece import Piece

GameboardType = {Tuple[int, int]: Piece}


