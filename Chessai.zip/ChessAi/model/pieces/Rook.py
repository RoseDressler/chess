from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.PieceType import PieceType
from model.pieces.Piece import Piece, chessCardinals


class Rook(Piece):

    def __init__(self, color: Color) -> None:
        super().__init__(color, PieceType.ROOK)

    def available_moves(self, gameboard: GameboardType, only_capturing_moves=False) -> [Move]:
        return self.ad_nauseum(gameboard, chessCardinals)

    def __repr__(self):
        return super().__repr__()

    def __str__(self):
        return super().__str__()