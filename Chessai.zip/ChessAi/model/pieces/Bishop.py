from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.PieceType import PieceType
from model.pieces.Piece import Piece, chessDiagonals


class Bishop(Piece):

    def __init__(self, color: Color) -> None:
        super().__init__(color, PieceType.BISHOP)

    def available_moves(self, gameboard: GameboardType, only_capturing_moves=False) -> [Move]:
        return self.ad_nauseum(gameboard, chessDiagonals)

    def __repr__(self):
        return super().__repr__()

    def __str__(self):
        return super().__str__()


