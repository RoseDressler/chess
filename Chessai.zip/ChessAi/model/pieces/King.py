from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.PieceType import PieceType
from model.pieces.Piece import Piece, _no_conflict


def king_list(x, y):
    return [(x + 1, y), (x + 1, y + 1), (x + 1, y - 1), (x, y + 1), (x, y - 1), (x - 1, y), (x - 1, y + 1),
            (x - 1, y - 1)]


class King(Piece):

    def __init__(self, color: Color) -> None:
        super().__init__(color, PieceType.KING)

    def available_moves(self, gameboard: GameboardType, only_capturing_moves=False) -> [Move]:
        x, y = self.get_position(gameboard)
        return [
            (Move(x, y, xx, yy)) for xx, yy in king_list(x, y)
            if _no_conflict(gameboard, self.color, xx, yy)
        ]

    def __repr__(self):
        return super().__repr__()

    def __str__(self):
        return super().__str__()