from ai.AI import AI
from model import MoveStatus, GameboardType
from model.Color import Color
from model.Move import Move
from model.PieceType import PieceType
from view.ChessView import ChessView

pieceChars = {Color.WHITE: {PieceType.PAWN: "♙", PieceType.ROOK: "♖", PieceType.KNIGHT: "♘", PieceType.BISHOP: "♗",
                            PieceType.KING: "♔", PieceType.QUEEN: "♕"},
              Color.BLACK: {PieceType.PAWN: "♟", PieceType.ROOK: "♜", PieceType.KNIGHT: "♞", PieceType.BISHOP: "♝",
                            PieceType.KING: "♚", PieceType.QUEEN: "♛"}}


def get_char(piecetype, color):
    return pieceChars[color][piecetype]


class ConsoleChessField(ChessView):

    def __init__(self, vs_bot: bool, playercolor: Color = None, bot: AI = None) -> None:
        super().__init__()
        self.playercolor = playercolor
        self.vs_bot = vs_bot
        self.ai = bot
        self.message = ""

    def parse_input(self, console_input: str):
        try:
            a, b = console_input.split()
            move = Move(ord(a[0]) - 97, int(a[1]) - 1, ord(b[0]) - 97, int(b[1]) - 1)
            print(a, b)
            return move
        except:
            print("error decoding input. please try again")
            return Move(-1, -1, -1, -1)

    def print_board(self, gameboard: GameboardType, turn_color=Color.WHITE):
        # turn the field depending on the color
        if turn_color == Color.BLACK:
            field_display = range(8)
        else:
            field_display = range(7, -1, -1)
        print("if you want to leave the game and save us tap(a9 a9)")
        print(" | A | B | C | D | E | F | G | H |")
        for i in field_display:
            print(end="  ")
            print("-" * 32)
            print(1 + i, end="| ")
            for j in range(8):
                item = gameboard.get((j, i))
                if item is not None:
                    char = get_char(item.piecetype, item.color)
                else:
                    char = " "

                print(char + ' |', end=" ")
            print("", end=str(1 + i))
            print()
        print(end="  ")
        print("-" * 32)
        print(" | A | B | C | D | E | F | G | H |")

    def on_game_start(self, gameboard: GameboardType):
        super().on_game_start(gameboard)
        print("chess program. enter moves in algebraic notation separated by space (e.g. 'a2 a3')")

    def on_turn_start(self, gameboard: GameboardType, turn_color: Color) -> Move:
        super().on_turn_start(gameboard, turn_color)
        if not self.vs_bot or self.playercolor == turn_color:
            self.print_board(gameboard, turn_color)
            print(self.message)
            self.message = ""
            print("It's your move " + str(turn_color) + ":")
            print(">", end="")
            cons_input = input()
            return self.parse_input(cons_input)
        elif self.playercolor != turn_color:
            print("The AI is analyzing. Prepare to get destroyed...")
            bot_move = self.ai.get_ai_move(gameboard)
            print("The AI used '" + str(bot_move) + "' it is very effective")
            return bot_move


    def on_turn_end(self, gameboard: GameboardType, move_status: MoveStatus):
        super().on_turn_end(gameboard, move_status)
        self.message = move_status
        print(move_status)

    def on_game_end(self, gameboard: GameboardType):
        super().on_game_end(gameboard)
