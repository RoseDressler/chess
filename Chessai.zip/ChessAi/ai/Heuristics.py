from model.Color import Color
from model.PieceType import PieceType


class Heuristics:
    piece_values = {PieceType.PAWN: 100, PieceType.ROOK: 500, PieceType.KNIGHT: 320, PieceType.BISHOP: 330,
                    PieceType.KING: 20000, PieceType.QUEEN: 900}

    # The tables denote the points scored for the position of the chess pieces on the board.

    PAWN_TABLE = [
        [ 0,  0,  0,  0,  0,  0,  0,  0],
        [ 5, 10, 10,-20,-20, 10, 10,  5],
        [ 5, -5,-10,  0,  0,-10, -5,  5],
        [ 0,  0,  0, 20, 20,  0,  0,  0],
        [ 5,  5, 10, 25, 25, 10,  5,  5],
        [10, 10, 20, 30, 30, 20, 10, 10],
        [50, 50, 50, 50, 50, 50, 50, 50],
        [ 0,  0,  0,  0,  0,  0,  0,  0]
    ]

    KNIGHT_TABLE = [
        [-50, -40, -30, -30, -30, -30, -40, -50],
        [-40, -20,   0,   5,   5,   0, -20, -40],
        [-30,   5,  10,  15,  15,  10,   5, -30],
        [-30,   0,  15,  20,  20,  15,   0, -30],
        [-30,   5,  15,  20,  20,  15,   0, -30],
        [-30,   0,  10,  15,  15,  10,   0, -30],
        [-40, -20,   0,   0,   0,   0, -20, -40],
        [-50, -40, -30, -30, -30, -30, -40, -50]
    ]

    BISHOP_TABLE = [
        [-20, -10, -10, -10, -10, -10, -10, -20],
        [-10,   5,   0,   0,   0,   0,   5, -10],
        [-10,  10,  10,  10,  10,  10,  10, -10],
        [-10,   0,  10,  10,  10,  10,   0, -10],
        [-10,   5,   5,  10,  10,   5,   5, -10],
        [-10,   0,   5,  10,  10,   5,   0, -10],
        [-10,   0,   0,   0,   0,   0,   0, -10],
        [-20, -10, -10, -10, -10, -10, -10, -20]
    ]

    ROOK_TABLE = [
        [ 0,  0,  0,  5,  5,  0,  0,  0],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [ 5, 10, 10, 10, 10, 10, 10,  5],
        [ 0,  0,  0,  0,  0,  0,  0,  0]
    ]

    QUEEN_TABLE = [
        [-20, -10, -10, -5, -5, -10, -10, -20],
        [-10,   0,   5,  0,  0,   0,   0, -10],
        [-10,   5,   5,  5,  5,   5,   0, -10],
        [  0,   0,   5,  5,  5,   5,   0,  -5],
        [ -5,   0,   5,  5,  5,   5,   0,  -5],
        [-10,   0,   5,  5,  5,   5,   0, -10],
        [-10,   0,   0,  0,  0,   0,   0, -10],
        [-20, -10, -10, -5, -5, -10, -10, -20]
    ]

    @staticmethod
    def evaluate(board):
        material = Heuristics.get_material_score(board)

        PAWN = Heuristics.get_piece_position_score(board, PieceType.PAWN, Heuristics.PAWN_TABLE)
        KNIGHT = Heuristics.get_piece_position_score(board, PieceType.KNIGHT, Heuristics.KNIGHT_TABLE)
        BISHOP = Heuristics.get_piece_position_score(board, PieceType.BISHOP, Heuristics.BISHOP_TABLE)
        ROOK = Heuristics.get_piece_position_score(board, PieceType.ROOK, Heuristics.ROOK_TABLE)
        QUEEN = Heuristics.get_piece_position_score(board, PieceType.QUEEN, Heuristics.QUEEN_TABLE)

        return material + PAWN + KNIGHT + BISHOP + ROOK + QUEEN

        # Returns the score for the position of the given type of piece.
        # A piece type can for example be: pieces.Pawn.PIECE_TYPE.
        # The table is the 2d numpy array used for the scoring. Example: Heuristics.PAWN_TABLE

    @staticmethod
    def get_piece_position_score(board, piecetype, table):
        white = 0
        black = 0
        for position, piece in board.items():
            if piece.piecetype == piecetype:
                if piece.color == Color.WHITE:
                    white += Heuristics.piece_values[piece.piecetype]
                else:
                    x, y = position
                    black += table[7 - x][y]
        return white - black


    @staticmethod
    def get_material_score(board):
        white = 0
        black = 0
        for position, piece in board.items():

            if piece.color == Color.WHITE:
                white += Heuristics.piece_values[piece.piecetype]
            else:
                black += Heuristics.piece_values[piece.piecetype]

        return white - black