# https://github.com/Dirk94/ChessAI/blob/master/ai.py
from ai.Heuristics import Heuristics
from model.Color import Color
from model.GameboardType import GameboardType
from controller.BoardEvaluation import is_check, clone_board, board_move_piece
from model.Move import Move


class AI:

    def __init__(self, color: Color) -> None:
        super().__init__()
        self.color = color

    INFINITE = 10000000

    @staticmethod
    def _get_possible_moves(board: GameboardType, color) -> [Move]:
        moves = []
        for pos, piece in board.items():
            if piece.color == color:
                moves += piece.available_moves(board)
        return moves

    @staticmethod
    def _is_invalid_move(move: Move, invalid_moves: [Move]):
        for invalid_move in invalid_moves:
            if invalid_move == move:
                return True
        return False

    def get_ai_move(self, board: GameboardType, invalid_moves=None) -> Move:
        if invalid_moves is None:
            invalid_moves = []
        best_move = Move.invalid()
        best_score = AI.INFINITE
        possible_moves = []
        for move in AI._get_possible_moves(board, self.color):
            if AI._is_invalid_move(move, invalid_moves):
                continue

            copy = clone_board(board)
            board_move_piece(copy, move)

            score = self._alphabeta(copy, 3, -AI.INFINITE, AI.INFINITE, True)
            if score < best_score:
                best_score = score
                best_move = move

        # Checkmate.
        if best_move == Move.invalid():
            return Move.invalid()

        copy = clone_board(board)
        board_move_piece(copy, best_move)

        check_state, check_color = is_check(board)
        if check_state and check_color == self.color:
            invalid_moves.append(best_move)
            return self.get_ai_move(board, invalid_moves)

        return best_move

    def _minimax(self, board: GameboardType, depth, maximizing):
        if depth == 0:
            return Heuristics.evaluate(board)

        if maximizing:
            best_score = -AI.INFINITE
            for move in AI._get_possible_moves(board, self.color.get_other_color()):
                copy = clone_board(board)
                board_move_piece(copy, move)

                score = self._minimax(copy, depth - 1, False)
                best_score = max(best_score, score)

            return best_score
        else:
            best_score = AI.INFINITE
            for move in AI._get_possible_moves(board, self.color):
                copy = clone_board(board)
                board_move_piece(copy, move)

                score = self._minimax(copy, depth - 1, True)
                best_score = min(best_score, score)

            return best_score

    def _alphabeta(self, board: GameboardType, depth, a, b, maximizing):
        if depth == 0:
            return Heuristics.evaluate(board)

        if maximizing:
            best_score = -AI.INFINITE
            for move in AI._get_possible_moves(board, self.color.get_other_color()):
                copy = clone_board(board)
                board_move_piece(copy, move)

                best_score = max(best_score, self._alphabeta(copy, depth - 1, a, b, False))
                a = max(a, best_score)
                if b <= a:
                    break
            return best_score
        else:
            best_score = AI.INFINITE
            for move in AI._get_possible_moves(board, self.color):
                copy = clone_board(board)
                board_move_piece(copy, move)

                best_score = min(best_score, self._alphabeta(copy, depth - 1, a, b, True))
                b = min(b, best_score)
                if b <= a:
                    break
            return best_score
