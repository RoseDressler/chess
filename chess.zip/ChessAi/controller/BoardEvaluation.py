import copy
from typing import Tuple, List

from model.Color import Color
from model.GameboardType import GameboardType
from model.Move import Move
from model.PieceType import PieceType
from model.pieces.Piece import Piece
from model.pieces.Queen import Queen


def __get_kings_and_pieces(gameboard: GameboardType) -> ({Color: Tuple[int, int]}, {Color: [Piece]}):
    """
    Creates two dicts with color as key. The first for the king positions, the second for the pieces
    :param gameboard:
    :return:
    """
    king_dict = {}
    piece_dict = {Color.BLACK: [], Color.WHITE: []}
    for position, piece in gameboard.items():
        if piece.piecetype == PieceType.KING:
            king_dict[piece.color] = position
        piece_dict[piece.color].append(piece)
    return king_dict, piece_dict


def _can_see_king(gameboard: GameboardType, kingpos: Tuple[int, int], piecelist: [Piece]):
    # checks if any pieces in piece list (which is an array of (piece,position) tuples) can see the king in kingpos
    for piece in piecelist:
        if piece.is_valid(kingpos, gameboard, only_capturing_moves=True):
            return True
    return False


def is_check(gameboard: GameboardType) -> (bool, Color):
    # ascertain where the kings are, check all pieces of opposing color against those kings, then if either get hit, check if its checkmate
    king_dict, piece_dict = __get_kings_and_pieces(gameboard)
    # white
    if _can_see_king(gameboard, king_dict[Color.WHITE], piece_dict[Color.BLACK]):
        # White player is in check
        return True, Color.WHITE
    if _can_see_king(gameboard, king_dict[Color.BLACK], piece_dict[Color.WHITE]):
        # Black player is in check
        return True, Color.BLACK
    return False, None


def is_check_mate(gameboard: GameboardType, turn_color: Color) -> bool:
    king_dict, piece_dict = __get_kings_and_pieces(gameboard)
    next_move_color = turn_color.get_other_color()
    pieces: List[Piece] = piece_dict[next_move_color]

    moves: [Move] = []
    for p in pieces:
        moves += p.available_moves(gameboard, only_capturing_moves=True)
    for m in moves:
        check_state, check_color = simulate_move(gameboard, m)
        if not check_state:
            # We found a move where the enemy is not in check
            return False
    return True

def _check_pawn_promotion(gameboard: GameboardType, piece: Piece):
    if piece.piecetype == PieceType.PAWN:
        x, y = piece.get_position(gameboard)
        if y == 0 or y == 7:
            new_piece = Queen(piece.color)
            new_piece.is_moved = True
            gameboard[(x, y)] = new_piece


def clone_board(gameboard: GameboardType) -> GameboardType:
    cloneboard: GameboardType = {}
    for pos, piece in gameboard.items():
        cloneboard[pos] = copy.deepcopy(piece)
    return cloneboard


def board_move_piece(gameboard: GameboardType, move: Move):
    start, end = (move.fromX, move.fromY), (move.toX, move.toY)
    piece = gameboard[start]
    piece.move()
    gameboard[end] = piece
    del gameboard[start]
    _check_pawn_promotion(gameboard, piece)


def simulate_move(gameboard: GameboardType, move: Move) -> (bool, Color):
    """Move the piece on a clone and calculate if it would be a check"""
    cloneboard = clone_board(gameboard)
    board_move_piece(cloneboard, move)
    return is_check(cloneboard)
