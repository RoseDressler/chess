import abc

from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.MoveStatus import MoveStatus


class ChessView(abc.ABC):
    @abc.abstractmethod
    def on_game_start(self, gameboard: GameboardType):
        pass

    @abc.abstractmethod
    def on_turn_start(self, gameboard: GameboardType, turn_color: Color) -> Move:
        pass

    @abc.abstractmethod
    def on_turn_end(self, gameboard: GameboardType, move_status: MoveStatus):
        pass

    @abc.abstractmethod
    def on_game_end(self, gameboard: GameboardType):
        pass