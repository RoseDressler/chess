import unittest

from controller.ChessGame import ChessGame
from controller.BoardEvaluation import _can_see_king, is_check, board_move_piece
from model.Color import Color
from model.GameStatus import GameStatus
from model.Move import Move
from model.MoveStatus import MoveStatus
from model.pieces.Bishop import Bishop
from model.pieces.King import King, king_list
from model.pieces.Knight import Knight, knight_list
from model.pieces.Pawn import Pawn
from model.PieceType import PieceType
from model.pieces.Piece import chessCardinals, chessDiagonals, _no_conflict, _is_in_bounds
from model.pieces.Queen import Queen
from model.pieces.Rook import Rook
from tests.MockChessView import MockChessView

MOCK_CHESS_VIEW = MockChessView([], [])
# MOCK_CHESS_QUICK_CHECK = MockChessView(
#     [Move(6, 0, 5, 2), Move(5, 2, 4, 4), Move(4, 4, 2, 5)],
#     [Move(0, 6, 0, 5), Move(0, 5, 0, 4)]
# )

class MyTestCase(unittest.TestCase):


    def test_gameboard_place_pieces_places_the_pieces_correctly(self):
        test = ChessGame(MOCK_CHESS_VIEW)
        correct_board = {
            (0, 0): PieceType.ROOK,
            (1, 0): PieceType.KNIGHT,
            (2, 0): PieceType.BISHOP,
            (3, 0): PieceType.KING,
            (4, 0): PieceType.QUEEN,
            (5, 0): PieceType.BISHOP,
            (6, 0): PieceType.KNIGHT,
            (7, 0): PieceType.ROOK,
            (0, 1): PieceType.PAWN,
            (1, 1): PieceType.PAWN,
            (2, 1): PieceType.PAWN,
            (3, 1): PieceType.PAWN,
            (4, 1): PieceType.PAWN,
            (5, 1): PieceType.PAWN,
            (6, 1): PieceType.PAWN,
            (7, 1): PieceType.PAWN,
            (0, 7): PieceType.ROOK,
            (1, 7): PieceType.KNIGHT,
            (2, 7): PieceType.BISHOP,
            (3, 7): PieceType.KING,
            (4, 7): PieceType.QUEEN,
            (5, 7): PieceType.BISHOP,
            (6, 7): PieceType.KNIGHT,
            (7, 7): PieceType.ROOK,
            (0, 6): PieceType.PAWN,
            (1, 6): PieceType.PAWN,
            (2, 6): PieceType.PAWN,
            (3, 6): PieceType.PAWN,
            (4, 6): PieceType.PAWN,
            (5, 6): PieceType.PAWN,
            (6, 6): PieceType.PAWN,
            (7, 6): PieceType.PAWN,
        }
        piece_counter = 32  # the correct number of pieces
        gameboard_to_test = test.gameboard
        for (i, j) in gameboard_to_test:
            piece = gameboard_to_test[(i, j)]
            correct_piece = correct_board[(i, j)]
            self.assertEqual(correct_piece, piece.piecetype)
            piece_counter -= 1
        self.assertEqual(0, piece_counter)

    def test_move_equals(self):
        # Arrange
        move1 = Move(0, 0, 1, 1)
        move2 = Move(0, 0, 1, 1)
        move_ne = Move(0, 1, 0, 1)
        # Act
        res = move1.equals(move2)
        # Assert
        self.assertTrue(res)
        self.assertEqual(move1, move2)
        self.assertNotEqual(move1, move_ne)

    def test_in_bounds(self):
        # valid bounds
        self.assertTrue(_is_in_bounds(0, 0))
        self.assertTrue(_is_in_bounds(7, 7))
        self.assertTrue(_is_in_bounds(3, 4))

        # invalid bounds
        self.assertFalse(_is_in_bounds(-1, -1))
        self.assertFalse(_is_in_bounds(0, -1))
        self.assertFalse(_is_in_bounds(8, -1))

    def test_ad_nauseum_correct_for_cardinals(self):
        # Arrange
        rook = Rook(Color.WHITE)
        gameboard = {(0, 0): rook}

        # generate from 0,1 to 0,7 and 1,0 to 7,0
        expected = [(Move(0, 0, 0, y)) for y in range(1, 8)] + [(Move(0, 0, x, 0)) for x in range(1, 8)]

        # Act
        result = rook.ad_nauseum(gameboard, chessCardinals)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_ad_nauseum_correct_for_diagonals(self):
        # Arrange
        bishop = Bishop(Color.WHITE)
        gameboard = {(0, 0): bishop}

        # generate from 1,1 to 7,7
        expected = [(Move(0, 0, i, i)) for i in range(1, 8)]

        # Act
        result = bishop.ad_nauseum(gameboard, chessDiagonals)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_ad_nauseum_correct_for_diagonals_and_cardinals(self):
        # Arrange
        queen = Queen(Color.WHITE)
        gameboard = {(0, 0): queen}

        # generate from 0,1 to 0,7 and 1,0 to 7,0 and 1,1 to 7,7
        expected = [(Move(0, 0, i, i)) for i in range(1, 8)] + [(Move(0, 0, 0, y)) for y in range(1, 8)] + [(Move(0, 0, x, 0)) for x in range(1, 8)]

        # Act
        result = queen.ad_nauseum(gameboard, chessDiagonals + chessCardinals)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_ad_nauseum_stops_on_friendly(self):
        # Arrange
        bishop = Bishop(Color.WHITE)
        pawn = Pawn(Color.WHITE)
        gameboard = {(0, 0): bishop, (1, 1): pawn}

        # generate from 1,1 to 7,7
        expected = []

        # Act
        result = bishop.ad_nauseum(gameboard, chessDiagonals)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_ad_nauseum_stops_on_enemy(self):
        # Arrange
        chess = ChessGame(MOCK_CHESS_VIEW)
        bishop = Bishop(Color.WHITE)
        pawn = Pawn(Color.BLACK)
        chess.gameboard = {(0, 0): bishop, (1, 1): pawn}

        expected = [Move(0, 0, 1, 1)]

        # Act
        result = bishop.ad_nauseum(chess.gameboard, chessDiagonals)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_no_conflict_works(self):
        pawn = Pawn(Color.WHITE)
        gameboard = {(1, 1): pawn}

        # Case 1
        # No conflict because the color differs
        result = _no_conflict(gameboard, Color.BLACK, 1, 1)
        self.assertTrue(result)

        # Case 2
        # Conflict because it's the same color
        result2 = _no_conflict(gameboard, Color.WHITE, 1, 1)
        self.assertFalse(result2)

    def test_available_moves_pawn_only_capturing_returns_correct_moves(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        pawn_enemy1 = Pawn(Color.BLACK)
        pawn_enemy2 = Pawn(Color.BLACK)
        pawn_enemy3 = Pawn(Color.BLACK)
        gameboard = {
            (1, 1): pawn,
            (0, 2): pawn_enemy1,
            (1, 3): pawn_enemy2,
            (2, 2): pawn_enemy3
        }
        expected = [Move(1, 1, 0, 2), Move(1, 1, 2, 2)]  # check that only moves are returned which capture an enemy

        # Act
        result = pawn.available_moves(gameboard, only_capturing_moves=True)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_available_moves_pawn_not_only_capturing_returns_all_moves(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        pawn_enemy1 = Pawn(Color.BLACK)
        pawn_enemy2 = Pawn(Color.BLACK)
        pawn_enemy3 = Pawn(Color.BLACK)
        gameboard = {
            (1, 1): pawn,
            (0, 2): pawn_enemy1,
            (1, 3): pawn_enemy2,
            (2, 2): pawn_enemy3
        }
        expected = [Move(1, 1, 0, 2), Move(1, 1, 1, 2), Move(1, 1, 2, 2)]  # check that all moves are returned (2xdiagonal, 1 straight)

        # Act
        result = pawn.available_moves(gameboard, only_capturing_moves=False)
        result2 = pawn.available_moves(gameboard)  # check that the default parameter is correct

        # Assert
        self.assertEqual(result, result2)
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_available_moves_pawn_if_not_moved(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        gameboard = {
            (1, 1): pawn
        }
        expected = [Move(1, 1, 1, 2), Move(1, 1, 1, 3)]

        # Act
        result = pawn.available_moves(gameboard)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_available_moves_pawn_if_moved(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        pawn.is_moved = True
        gameboard = {
            (1, 2): pawn
        }
        expected = [Move(1, 2, 1, 3)]

        # Act
        result = pawn.available_moves(gameboard)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_king_moves_correct(self):
        # Arrange
        king = King(Color.WHITE)
        gameboard = {
            (1, 1): king
        }
        expected = [(Move(1, 1, xx, yy)) for xx, yy in king_list(1, 1)]

        # Act
        result = king.available_moves(gameboard)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_knight_moves_correct(self):
        # Arrange
        knight = Knight(Color.WHITE)
        gameboard = {
            (4, 4): knight
        }
        expected = [(Move(4, 4, xx, yy)) for xx, yy in knight_list(4, 4, 2, 1)]

        # Act
        result = knight.available_moves(gameboard)

        # Assert
        intersection = list(set(result).intersection(expected))
        self.assertEqual(len(expected), len(result))
        self.assertEqual(len(expected), len(intersection))

    def test_move(self):
        # Arrange
        pawn = Pawn(Color.WHITE)

        # Act
        pawn.move()

        # Assert
        self.assertTrue(pawn.is_moved)

    def test_can_see_king_multiple_enemies(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        rook = Rook(Color.WHITE)
        queen = Queen(Color.WHITE)

        king = King(Color.BLACK)
        gameboard = {
            (1, 1): pawn,
            (4, 2): rook,
            (5, 5): queen,
            (2, 2): king
        }

        white_pieces = [pawn, rook, queen]

        # Act
        result = _can_see_king(gameboard, king.get_position(gameboard), white_pieces)
        # Assert
        self.assertTrue(result)

    def test_can_see_king_king_not_seen(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        rook = Rook(Color.WHITE)
        king = King(Color.BLACK)
        gameboard = {
            (1, 1): pawn,
            (4, 2): rook,
            (3, 3): king
        }

        white_pieces = [pawn, rook]

        # Act
        result = _can_see_king(gameboard, king.get_position(gameboard), white_pieces)
        # Assert
        self.assertFalse(result)
        
    def test_is_check(self):
        # Arrange
        pawn_w = Pawn(Color.WHITE)
        rook_w = Rook(Color.WHITE)
        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        gameboard = {
            (1, 1): pawn_w,
            (4, 2): rook_w,
            (5, 3): king_w,
            (2, 2): king_b
        }

        # Act
        result = is_check(gameboard)

        # Assert
        self.assertTrue(result[0])
        self.assertEqual(Color.BLACK, result[1])

    def test_is_check_not_in_check(self):
        # Arrange
        pawn_b = Pawn(Color.BLACK)
        rook_b = Rook(Color.BLACK)
        king_b = King(Color.BLACK)
        king_w = King(Color.WHITE)
        gameboard = {
            (1, 7): pawn_b,
            (4, 7): rook_b,
            (2, 2): king_b,
            (5, 3): king_w
        }

        # Act
        result = is_check(gameboard)

        # Assert
        self.assertFalse(result[0])
        self.assertEqual(None, result[1])

    def test_move_piece_returns_correct_status_no_piece(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        pawn = Pawn(Color.WHITE)
        game.gameboard = {
            (0, 0): pawn
        }
        # Act
        result = game._move_piece(Move(1, 1, 1, 2))
        # Assert
        self.assertEqual(MoveStatus.NO_PIECE, result)

    def test_move_piece_returns_correct_status_invalid_color(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.WHITE
        pawn = Pawn(Color.BLACK)
        game.gameboard = {
            (0, 7): pawn
        }
        # Act
        result = game._move_piece(Move(0, 7, 0, 6))
        # Assert
        self.assertEqual(MoveStatus.INVALID_COLOR, result)

    def test_move_piece_returns_correct_status_move_would_put_player_in_check(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.BLACK
        rook_w = Rook(Color.WHITE)
        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (0, 0): rook_w,
            (7, 7): king_w,
            (1, 1): king_b
        }
        # Act
        result = game._move_piece(Move(1, 1, 0, 1))
        # Assert
        self.assertEqual(MoveStatus.MOVE_WOULD_PUT_PLAYER_IN_CHECK, result)

    def test_move_piece_returns_correct_status_check(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.WHITE
        rook_w = Rook(Color.WHITE)
        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (0, 0): rook_w,
            (7, 7): king_w,
            (1, 1): king_b
        }
        # Act
        result = game._move_piece(Move(0, 0, 0, 1))
        # Assert
        self.assertEqual(MoveStatus.CHECK, result)

    def test_move_piece_can_resolve_check(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.BLACK
        rook_w = Rook(Color.WHITE)
        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (1, 0): rook_w,
            (7, 7): king_w,
            (1, 1): king_b
        }
        # Act
        result = game._move_piece(Move(1, 1, 1, 0))
        # Assert
        self.assertEqual(MoveStatus.VALID_MOVE, result)

    def test_move_piece_still_in_check_not_valid(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.BLACK
        rook_w = Rook(Color.WHITE)
        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (1, 0): rook_w,
            (7, 7): king_w,
            (1, 1): king_b
        }
        # Act
        result = game._move_piece(Move(1, 1, 1, 2))
        # Assert
        self.assertEqual(MoveStatus.MOVE_WOULD_PUT_PLAYER_IN_CHECK, result)

    def test_move_piece_status_correct_move_not_available(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.WHITE
        rook_w = Rook(Color.WHITE)
        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (1, 0): rook_w,
            (7, 7): king_w,
            (1, 1): king_b
        }
        # Act
        result = game._move_piece(Move(1, 0, 2, 2))
        # Assert
        self.assertEqual(MoveStatus.MOVE_NOT_AVAILABLE, result)

    def test_move_piece_status_correct_valid_move(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.WHITE
        rook_w = Rook(Color.WHITE)
        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (3, 0): rook_w,
            (7, 7): king_w,
            (0, 7): king_b
        }
        # Act
        result = game._move_piece(Move(3, 0, 3, 3))
        # Assert
        self.assertEqual(MoveStatus.VALID_MOVE, result)

    def test_move_piece_status_correct_check_mate(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.WHITE
        rook_w = Rook(Color.WHITE)
        rook_w2 = Rook(Color.WHITE)
        queen_w = Queen(Color.WHITE)

        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (2, 2): rook_w,
            (2, 0): rook_w2,
            (0, 7): queen_w,
            (7, 7): king_w,
            (1, 1): king_b
        }
        # Act
        result = game._move_piece(Move(0, 7, 0, 0))
        # Assert
        self.assertEqual(MoveStatus.CHECK_MATE, result)

    def test_move_piece_status_correct_draw(self):
        # Arrange
        game = ChessGame(MOCK_CHESS_VIEW)
        game.playersturn = Color.WHITE
        rook_w = Rook(Color.WHITE)
        queen_w = Queen(Color.WHITE)
        queen_w2 = Queen(Color.WHITE)

        king_w = King(Color.WHITE)
        king_b = King(Color.BLACK)
        game.gameboard = {
            (0, 7): queen_w,
            (3, 3): queen_w2,
            (4, 1): rook_w,
            (7, 7): king_w,
            (1, 2): king_b
        }
        # Act
        result = game._move_piece(Move(0, 7, 0, 0))
        # Assert
        self.assertEqual(MoveStatus.DRAW, result)

    # def test_chess_main_checkmate(self):
    #     # Arrange
    #     game = ChessGame(MOCK_CHESS_QUICK_CHECK)
    #     game.playersturn = Color.WHITE
    #
    #     # Act
    #     result = game.main()
    #     # Assert
    #     self.assertEqual(GameStatus.WON_WHITE, result)

    def test_other_color(self):
        # Arrange
        color = Color.WHITE
        color2 = Color.BLACK

        # Act
        result = color.get_other_color()
        result2 = color2.get_other_color()

        # Assert
        self.assertEqual(Color.BLACK, result)
        self.assertEqual(Color.WHITE, result2)

    def test_board_move_piece(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        gameboard = {
            (1, 1): pawn
        }

        # Act
        board_move_piece(gameboard, Move(1, 1, 0, 0))

        # Assert
        self.assertIsNotNone(gameboard[(0, 0)])

    def test_pawn_promotion(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        gameboard = {(0, 6): pawn}
        # Act
        board_move_piece(gameboard, Move(0, 6, 0, 7))
        # Assert
        self.assertEqual(PieceType.QUEEN, gameboard[(0, 7)].piecetype)

    def test_pawn_promotion_not_triggered(self):
        # Arrange
        pawn = Pawn(Color.WHITE)
        gameboard = {(0, 5): pawn}
        # Act
        board_move_piece(gameboard, Move(0, 5, 0, 6))
        # Assert
        self.assertNotEqual(PieceType.QUEEN, gameboard[(0, 6)].piecetype)

    def test_pawn_promotion_black(self):
        # Arrange
        pawn = Pawn(Color.BLACK)
        gameboard = {(0, 1): pawn}
        # Act
        board_move_piece(gameboard, Move(0, 1, 0, 0))
        # Assert
        self.assertEqual(PieceType.QUEEN, gameboard[(0, 0)].piecetype)

if __name__ == '__main__':
    unittest.main()
