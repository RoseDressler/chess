import abc

from typing import Tuple

from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.PieceType import PieceType

chessCardinals = [(1, 0), (0, 1), (-1, 0), (0, -1)]
chessDiagonals = [(1, 1), (-1, 1), (1, -1), (-1, -1)]


def _is_in_bounds(x, y):
    "checks if a position is on the board"
    if x >= 0 and x < 8 and y >= 0 and y < 8:
        return True
    return False


def _no_conflict(gameboard, initialColor, x, y):
    "checks if a single position poses no conflict to the rules of chess"
    if _is_in_bounds(x, y) and (((x, y) not in gameboard) or gameboard[(x, y)].color != initialColor):
        return True
    return False


class Piece(abc.ABC):

    def __init__(self, color: Color, piecetype: PieceType) -> None:
        self.color = color
        self.piecetype = piecetype
        self.position = None
        self.is_moved = False

    def __repr__(self) -> str:
        colorstr = "W"
        if self.color == Color.BLACK:
            colorstr = "B"
        return self.piecetype.name.capitalize() + ' ' + colorstr

    def __str__(self) -> str:
        colorstr = "W"
        if self.color == Color.BLACK:
            colorstr = "B"
        return self.piecetype.name.capitalize() + ' ' + colorstr

    def is_valid(self, endpos, gameboard: GameboardType, only_capturing_moves=True) -> bool:
        x, y = self.get_position(gameboard)
        x_to, y_to = endpos
        if Move(x, y, x_to, y_to) in self.available_moves(gameboard):
            return True
        return False

    @abc.abstractmethod
    def available_moves(self, gameboard: GameboardType, only_capturing_moves=False) -> [Move]:
        pass

    def ad_nauseum(self, gameboard: GameboardType, intervals) -> [Move]:
        """repeats the given interval until another piece is run into.
        if that piece is not of the same color, that square is added and
         then the list is returned"""
        position = self.get_position(gameboard)

        x = position[0]
        y = position[1]
        answers: [Move] = []
        for xint, yint in intervals:
            xtemp, ytemp = x + xint, y + yint
            while _is_in_bounds(xtemp, ytemp):
                # print(str((xtemp,ytemp))+"is in bounds")

                target = gameboard.get((xtemp, ytemp), None)
                if target is None:
                    answers.append(Move(x, y, xtemp, ytemp))
                elif target.color != self.color:
                    answers.append(Move(x, y, xtemp, ytemp))
                    break
                else:
                    break

                xtemp, ytemp = xtemp + xint, ytemp + yint
        return answers

    def move(self):
        self.is_moved = True

    def get_position(self, gameboard: GameboardType) -> Tuple[int, int]:
        """
        Get the position for a piece on the gameboard
        :param gameboard: The gameboard where the piece is positioned
        :param piece: the piece to look for (searched  by reference)
        :return: the position of the piece, or (-1, -1) if not found
        """
        for pos, p in gameboard.items():
            if self == p:
                return pos
        return -1, -1
