from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.PieceType import PieceType
from model.pieces.Piece import Piece, _no_conflict


def knight_list(x, y, int1, int2):
    """specifically for the rook, permutes the values needed around a position for noConflict tests"""
    return [(x + int1, y + int2), (x - int1, y + int2), (x + int1, y - int2), (x - int1, y - int2),
            (x + int2, y + int1), (x - int2, y + int1), (x + int2, y - int1), (x - int2, y - int1)]


class Knight(Piece):

    def __init__(self, color: Color) -> None:
        super().__init__(color, PieceType.KNIGHT)

    def available_moves(self, gameboard: GameboardType, only_capturing_moves=False) -> [Move]:
        x, y = self.get_position(gameboard)
        return [(Move(x, y, xx, yy)) for xx, yy in knight_list(x, y, 2, 1) if
                _no_conflict(gameboard, self.color, xx, yy)]

    def __repr__(self):
        return super().__repr__()

    def __str__(self):
        return super().__str__()