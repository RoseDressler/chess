from typing import Tuple

from model import GameboardType
from model.Color import Color
from model.Move import Move
from model.PieceType import PieceType
from model.pieces.Piece import Piece, _no_conflict


class Pawn(Piece):

    def __init__(self, color: Color):
        super().__init__(color, PieceType.PAWN)
        # of course, the smallest piece is the hardest to code. direction should be either 1 or -1, should be -1 if
        # the pawn is traveling "backwards"
        self.direction = 1
        if self.color == Color.BLACK:
            self.direction = -1

    def available_moves(self, gameboard: GameboardType, only_capturing_moves=False) -> [Move]:
        x, y = self.get_position(gameboard)

        answers = []
        if (x + 1, y + self.direction) in gameboard and _no_conflict(gameboard, self.color, x + 1, y + self.direction):
            answers.append(Move(x, y, x + 1, y + self.direction))
        if (x - 1, y + self.direction) in gameboard and _no_conflict(gameboard, self.color, x - 1, y + self.direction):
            answers.append(Move(x, y, x - 1, y + self.direction))
        # the condition after the 'and' is to make sure the non-capturing movement (the only one in the game) is not
        # used in the calculation of checkmate (the forward moves of the pawn cannot capture another figure!)
        if (x, y + self.direction) not in gameboard and only_capturing_moves is False:
            answers.append(Move(x, y, x, y + self.direction))
            # if the pawn could move one position was not moved yet allow it to move 2 fields
            if (x, y + (2 * self.direction)) not in gameboard and not self.is_moved:
                answers.append(Move(x, y, x, y + 2 * self.direction))

        return answers

    def __repr__(self):
        return super().__repr__()

    def __str__(self):
        return super().__str__()
