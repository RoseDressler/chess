from enum import Enum


class MoveStatus(Enum):
    VALID_MOVE = 1
    INVALID_COLOR = 2
    NO_PIECE = 3
    MOVE_NOT_AVAILABLE = 4
    MOVE_WOULD_PUT_PLAYER_IN_CHECK = 5
    CHECK = 6
    CHECK_MATE = 7
    DRAW = 8
    STOP_AND_SAVE = 9