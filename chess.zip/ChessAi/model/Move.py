class Move:
    def __init__(self, fromX: int, fromY: int, toX: int, toY: int) -> None:
        super().__init__()
        self.fromX: int = fromX
        self.fromY: int = fromY
        self.toX: int = toX
        self.toY: int = toY

    def __eq__(self, o: object) -> bool:
        return self.equals(o)

    def __hash__(self) -> int:
        return self.fromX.__hash__() + self.fromY.__hash__() + self.toX.__hash__() + self.toY.__hash__()

    def __ne__(self, o: object) -> bool:
        return not self.equals(o)

    def equals(self, other_move):
        return self.fromX == other_move.fromX and self.fromY == other_move.fromY and self.toX == other_move.toX and \
               self.toY == other_move.toY

    def __repr__(self) -> str:
        return 'Move(' + str(self.fromX) + ', ' + str(self.fromY) + ', ' + str(self.toX) + ', ' + str(self.toY) + ')'

    def __str__(self) -> str:
        return chr(self.fromX + 97) + str(self.fromY + 1) + ' ' + chr(self.toX + 97) + str(self.toY + 1)

    @classmethod
    def default(cls):
        return cls(0, 0, 0, 0)

    @classmethod
    def invalid(cls):
        return cls(-1, -1, -1, -1)