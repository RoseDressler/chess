from enum import Enum


class GameStatus(Enum):
    WON_WHITE = 0
    WON_BLACK = 1
    DRAW = 2
    SAVE = 3
    QUIT = 4